# Directorio "result"

Los archivos aquí contenidos se generarán y utilizarán durante el proceso ETL