# Directorio "assets"

Los archivos aquí contenidos representan los datos fuente que se utilizarán en el proceso ETL